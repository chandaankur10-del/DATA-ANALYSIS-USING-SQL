create table store(
store_id int primary key,
store_name varchar(50),
city varchar(50),
state varchar(20)

);

create table sales(
sale_id int primary key,
customer_id int,
product_id int,
quantity int,
sale_date Date,
store_id int

);

create table customers(
customer_id int primary key,
name varchar(50),
city varchar(30),
state varchar(30),	
join_date date
);

create table products(
product_id int primary key,
product_name varchar(50),
category varchar(50),
price numeric(10,2)
);

--Total revenue & sales

select 
    sum(quantity) as total_unit_sold,
    sum(quantity*price) as Revenue 
	from sales a 
	join 
	products b 
	on a.product_id=b.product_id;

--Top 5 products by revenue

SELECT 
    p.product_id,
    p.product_name,
    SUM(s.quantity) AS total_units_sold,
    p.price,
    SUM(s.quantity * p.price) AS total_revenue
FROM sales s
JOIN products p 
    ON s.product_id = p.product_id
GROUP BY p.product_id, p.product_name, p.price
ORDER BY total_revenue DESC
LIMIT 5;

-- Monthly Sales Trend

SELECT 
    TO_CHAR(s.sale_date, 'YYYY-MM') AS sale_month,
    SUM(s.quantity) AS total_units_sold,
    SUM(s.quantity * p.price) AS total_revenue
FROM sales s
JOIN products p 
    ON s.product_id = p.product_id
GROUP BY sale_month
ORDER BY sale_month;

--Sales by State / City

select 
sum(s.quantity) as total_sales,
c.state as state_ 
from customers c join sales s on c.customer_id=s.customer_id
group by c.state;

--Customer Lifetime Value 

SELECT  
    c.customer_id,  
    c.name AS customer_name,  
    SUM(p.price * s.quantity) AS total_spent
FROM sales s
JOIN products p  
    ON s.product_id = p.product_id
JOIN customers c  
    ON c.customer_id = s.customer_id
GROUP BY c.customer_id, c.name

--Store Performance Ranking
select s.store_name as store__name,sum(q.quantity)as Total_Sold, sum(q.quantity*p.price)as Amount_sold
from store s join sales q on s.store_id=q.store_id join products p on q.product_id=p.product_id 
group by store__name order by Amount_sold desc ;

--Best Month for Sales

select sum(q.quantity*p.price) as max_sales, 
to_char(q.sale_date,'MM') as month_of_year
from sales q join products p on p.product_id=q.product_id group by month_of_year order by max_sales desc
limit 1;

--Category-wise Revenue Contribution

select p.category as CATEGORY, sum(q.quantity*p.price) as revenue
 from products p join sales q on p.product_id = q.product_id group by CATEGORY;

--Year-over-Year Growth

select to_char(q.sale_date,'YYYY') as Year ,
sum(q.quantity*p.price) as Revenue from sales q join products p on p.product_id = q.product_id 
group by Year
